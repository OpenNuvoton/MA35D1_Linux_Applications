#!/bin/sh

#define a new path for the font in qt5
export QT_QPA_FONTDIR=/usr/share/fonts/truetype
export XDG_RUNTIME_DIR="/tmp/runtime-root"
export QT_QPA_PLATFORM="linuxfb"
export QT_QPA_FB_TSLIB=1
export TSLIB_CONSOLEDEVICE=none


if [ -e /dev/input/touchscreen0 ]; then
    TSLIB_TSDEVICE=/dev/input/touchscreen0

    export TSLIB_TSDEVICE
fi

#clean boot Logo
cd /opt
./fb_clean 0

#Check touchscreen calibration 
test -e /etc/pointercal && echo "pointercal exist" || ts_calibrate

#Init Demo
#The order of this script must be later than qt5-env.sh
cd /opt
echo "MA35D1 DEMO start..."
./MA35D1_DEMO &